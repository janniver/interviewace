import whisper
print(whisper.__file__)